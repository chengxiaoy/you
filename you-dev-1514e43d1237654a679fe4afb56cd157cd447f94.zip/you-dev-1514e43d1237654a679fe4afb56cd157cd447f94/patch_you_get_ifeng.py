#!/usr/bin/env python
# -*- coding: utf-8 -*-

from you_get.common import *

import json
import re


def _download_by_id(id, title=None, output_dir='.', merge=True, info_only=False):
    assert r1(r'([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})', id), id
    url = 'http://vxml.ifengimg.com/video_info_new/%s/%s/%s.xml' % (id[-2], id[-2:], id)
    xml = get_html(url, 'utf-8')
    title = r1(r'Name="([^"]+)"', xml)
    title = unescape_html(title)
    url = r1(r'VideoPlayUrl="([^"]+)"', xml)
    from random import randint
    r = randint(10, 19)
    url = url.replace('http://video.ifeng.com/', 'http://video%s.ifeng.com/' % r)
    return url
