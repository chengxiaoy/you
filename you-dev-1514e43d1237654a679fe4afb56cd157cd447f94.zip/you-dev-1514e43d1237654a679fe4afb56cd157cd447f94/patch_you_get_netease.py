#!/usr/bin/env python
# -*- coding: utf-8 -*-

from you_get.common import *
from you_get.extractors import VideoExtractor

from you_get.extractors.netease import make_url
from you_get.extractors.netease import encrypted_id

import hashlib
import re
from json import loads

import base64
import ssl
import time
import traceback

def _download_by_url(url):
    if "163.fm" in url:
        url = get_location(url)
    if "music.163.com" in url:
        rid = match1(url, r'id=(.*)')
        if rid is None:
            rid = match1(url, r'/(\d+)/?$')
        if "song" in url:
            j = loads(get_content("http://music.163.com/api/song/detail/?id=%s&ids=[%s]&csrf_token=" % (rid, rid), headers={"Referer": "http://music.163.com/"}))
            return netease_song_download(j["songs"][0])
    else:
        html = get_decoded_html(url)

        title = r1('movieDescription=\'([^\']+)\'', html) or r1('<title>(.+)</title>', html)

        if title[0] == ' ':
            title = title[1:]

        src = r1(r'<source src="([^"]+)"', html) or r1(r'<source type="[^"]+" src="([^"]+)"', html)

        if src:
            url = src
            _, ext, size = url_info(src)
            #sd_url = r1(r'(.+)-mobile.mp4', src) + ".flv"
            #hd_url = re.sub('/SD/', '/HD/', sd_url)

        else:
            url = (r1(r'["\'](.+)-list.m3u8["\']', html) or r1(r'["\'](.+).m3u8["\']', html)) + ".mp4"
            _, _, size = url_info(url)
            ext = 'mp4'

        return url

def netease_song_download(song):
    title = "%s. %s" % (song['position'], song['name'])
    songNet = 'p' + song['mp3Url'].split('/')[2][1:]

    if 'hMusic' in song and song['hMusic'] != None:
        url_best = make_url(songNet, song['hMusic']['dfsId'])
    elif 'mp3Url' in song:
        url_best = song['mp3Url']
    elif 'bMusic' in song:
        url_best = make_url(songNet, song['bMusic']['dfsId'])

    return url_best
