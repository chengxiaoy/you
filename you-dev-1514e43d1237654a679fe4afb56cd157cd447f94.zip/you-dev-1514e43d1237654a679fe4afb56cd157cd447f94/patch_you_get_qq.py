#!/usr/bin/env python
# -*- coding: utf-8 -*-

from you_get.common import *
from urllib.parse import urlparse,parse_qs

def _download_by_url(url, output_dir='.', merge=True, info_only=False, **kwargs):
    if url.startswith('https://'):
        url = url[8:]
    if not url.startswith('http://'):
        url = 'http://' + url
    content = get_html(url)
    vid = parse_qs(urlparse(url).query).get('vid') #for links specified vid  like http://v.qq.com/cover/p/ps6mnfqyrfo7es3.html?vid=q0181hpdvo5
    vid = vid[0] if vid else match1(content, r'vid"*\s*:\s*"\s*([^"]+)"') #general fallback
    if not vid:
        url = match1(content, r'url=\s*([^"]+)"')
        if url.startswith('https://'):
            url = url[8:]
        if not url.startswith('http://'):
            url = 'http://' + url
        content = get_html(url)
        vid = match1(content, r'vid\s*:\s*"\s*([^"]+)"')

    info_api = 'http://vv.video.qq.com/getinfo?otype=json&appver=3%2E2%2E19%2E333&platform=11&defnpayver=1&vid=' + vid
    info = get_html(info_api)
    video_json = json.loads(match1(info, r'QZOutputJson=(.*)')[:-1])
    parts_vid = video_json['vl']['vi'][0]['vid']
    parts_ti = video_json['vl']['vi'][0]['ti']
    parts_prefix = video_json['vl']['vi'][0]['ul']['ui'][0]['url']
    parts_formats = video_json['fl']['fi']
    if parts_prefix.endswith('/'):
        parts_prefix = parts_prefix[:-1]
    # find best quality
    # only looking for fhd(1080p) and shd(720p) here.
    # 480p usually come with a single file, will be downloaded as fallback.
    best_quality = ''
    for part_format in parts_formats:
        if part_format['name'] == 'fhd':
            best_quality = 'fhd'
            break

        if part_format['name'] == 'shd':
            best_quality = 'shd'

    for part_format in parts_formats:
        if (not best_quality == '') and (not part_format['name'] == best_quality):
            continue
        part_format_id = part_format['id']
        part_format_sl = part_format['sl']
        if part_format_sl == 0:
            part_urls= []
            total_size = 0
            try:
                # For fhd(1080p), every part is about 100M and 6 minutes
                # try 100 parts here limited download longest single video of 10 hours.
                for part in range(1,100):
                    filename = vid + '.p' + str(part_format_id % 10000) + '.' + str(part) + '.mp4'
                    key_api = "http://vv.video.qq.com/getkey?otype=json&platform=11&format=%s&vid=%s&filename=%s" % (part_format_id, parts_vid, filename)
                    #print(filename)
                    #print(key_api)
                    part_info = get_html(key_api)
                    key_json = json.loads(match1(part_info, r'QZOutputJson=(.*)')[:-1])
                    #print(key_json)
                    vkey = key_json['key']
                    url = '%s/%s?vkey=%s' % (parts_prefix, filename, vkey)
                    part_urls.append(url)
                    _, ext, size = url_info(url, faker=True)
                    total_size += size
            except:
                pass
            if not info_only:
                return part_urls
        else:
            fvkey = video_json['vl']['vi'][0]['fvkey']
            mp4 = video_json['vl']['vi'][0]['cl'].get('ci', None)
            if mp4:
                old_id = mp4[0]['keyid'].split('.')[1]
                new_id = 'p' + str(int(old_id) % 10000)
                mp4 = mp4[0]['keyid'].replace(old_id, new_id) + '.mp4'
            else:
                mp4 = video_json['vl']['vi'][0]['fn']
            url = '%s/%s?vkey=%s' % ( parts_prefix, mp4, fvkey )
            _, ext, size = url_info(url, faker=True)

            if not info_only:
                return [url]
