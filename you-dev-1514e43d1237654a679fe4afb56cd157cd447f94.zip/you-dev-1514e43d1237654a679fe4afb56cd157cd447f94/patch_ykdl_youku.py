#!/usr/bin/env python
# -*- coding: utf-8 -*-

import ykdl.extractors.youku as youku

import base64
import ssl
import time
import traceback


def _download_by_url(url):
        parser = youku.site.parser
        info = parser(url)
        urls = info.streams['SD']['src']
        return urls
