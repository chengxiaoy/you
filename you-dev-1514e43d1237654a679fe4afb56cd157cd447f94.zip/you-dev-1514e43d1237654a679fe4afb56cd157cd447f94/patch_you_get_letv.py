#!/usr/bin/env python
# -*- coding: utf-8 -*-

from you_get.common import *
from you_get.extractors import VideoExtractor

from you_get.extractors.le import calcTimeKey
from you_get.extractors.le import decode

import re
import time
import random

def _video_info(url):
    html = get_content(url)
    vid = match1(url, r'http://www.letv.com/ptv/vplay/(\d+).html') or \
            match1(url, r'http://www.le.com/ptv/vplay/(\d+).html') or \
            match1(html, r'vid="(\d+)"')
    url = 'http://api.letv.com/mms/out/video/playJson?id={}&platid=1&splatid=101&format=1&tkey={}&domain=www.letv.com'.format(vid,calcTimeKey(int(time.time())))
    r = get_content(url, decoded=False)
    info=json.loads(str(r,"utf-8"))


    stream_id = None
    support_stream_id = info["playurl"]["dispatch"].keys()
    print("Current Video Supports:")
    for i in support_stream_id:
        print("\t--format",i,"<URL>")
    if "1080p" in support_stream_id:
        stream_id = '1080p'
    elif "720p" in support_stream_id:
        stream_id = '720p'
    else:
        stream_id =sorted(support_stream_id,key= lambda i: int(i[1:]))[-1]

    url =info["playurl"]["domain"][0]+info["playurl"]["dispatch"][stream_id][0]
    url+="&ctv=pc&m3v=1&termid=1&format=1&hwtype=un&ostype=Linux&tag=letv&sign=letv&expect=3&tn={}&pay=0&iscpn=f9051&rateid={}".format(random.random(),stream_id)

    r2=get_content(url,decoded=False)
    info2=json.loads(str(r2,"utf-8"))

    # hold on ! more things to do
    # to decode m3u8 (encoded)
    m3u8 = get_content(info2["location"],decoded=False)
    m3u8_list = decode(m3u8)
    urls = re.findall(r'^[^#][^\r]*',m3u8_list,re.MULTILINE)
    return urls
