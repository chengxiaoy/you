#! /usr/bin/env python3
# coding=utf-8
# @author francis

from __future__ import unicode_literals

import sys
import re

sys.path.append('you-get/src')
sys.path.append('youtube-dl')
sys.path.append('ykdl')

import youtube_dl
import you_get.extractors.kugou as kugou
import you_get.extractors.youku as youku
from you_get import common
#  import you_get.extractors.letv as letv
import you_get.extractors.sohu as sohu
import you_get.extractors.qq as qq
import you_get.extractors.iqiyi as iqiyi
import simplejson as json
import hashlib

from bottle import route, run, request, response

import patch_you_get_youku
import patch_you_get_qq
import patch_you_get_iqiyi
import patch_you_get_cntv
import patch_you_get_ifeng
import patch_you_get_bilibili
import patch_you_get_netease
import patch_you_get_sohu
import patch_you_get_letv
import patch_you_get_xiami
import patch_you_get_kugou
import patch_ykdl_youku
import requests
from expiringdict import ExpiringDict
cache = ExpiringDict(max_len=100, max_age_seconds=300)

#  import signal
#  import faulthandler
#  faulthandler.register(signal.SIGUSR1)

#  http://stackoverflow.com/questions/132058/showing-the-stack-trace-from-a-running-python-application
import os, code, traceback, signal

def debug(sig, frame):
    """Interrupt running process, and provide a python prompt for
    interactive debugging."""
    d={'_frame':frame}         # Allow access to frame object.
    d.update(frame.f_globals)  # Unless shadowed by global
    d.update(frame.f_locals)

    #  i = code.InteractiveConsole(d)
    message  = "Signal received : entering python shell.\nTraceback:\n"
    message += ''.join(traceback.format_stack(frame))
    print(message)
    with open('/tmp/you.dump.log', 'a') as f:
        f.write(message + "\n")
    #  i.interact(message)
signal.signal(signal.SIGUSR1, debug)


@route('/analysis')
def analysis_source_url():
    """调用youtube-dl解析源地址,由于不同的网站返回结果不同不能直接返回真实的下载地址,因此返回一个json"""
    result = None
    ydl_opts = {}
    source_url = request.query.source_url
    if source_url:
        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            extract_result = ydl.extract_info(source_url, download=False)
            result = json.dumps(extract_result)
    return result

@route('/youtube_with_proxy')
def youtube_with_proxy():
    """调用youtube-dl解析源地址,由于不同的网站返回结果不同不能直接返回真实的下载地址,因此返回一个json"""
    result = None
    ydl_opts = {"proxy": "192.168.62.123:7777"}
    url = request.query.url
    if url:
        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            extract_result = ydl.extract_info(url, download=False)
            result = json.dumps(extract_result)
    return result

@route("/")
def analysis_all():
    pass


youku.Youku._download_by_vid = patch_you_get_youku._download_by_vid
youku.Youku._download_by_url = patch_you_get_youku._download_by_url
youku.Youku._download_by_vid_for_blog = patch_you_get_youku._download_by_vid_for_blog
#youku.Youku.prepare = patch_you_get_youku.prepare

@route('/youku')
def analysis_youku():
    url = request.query.url
    yk = youku.Youku()
    ret = yk._download_by_url(url)
    return json.dumps(ret)

@route('/youku4blog')
def analysis_youku():
    url = request.query.url
    #  print(url)
    cached = cache.get(url)
    if cached:
        response.set_header('Access-Control-Allow-Origin', '*')
        return cached
    else:
        yk = youku.Youku()
        #  print(youku.Youku.get_vid_from_url(url))
        re = yk._download_by_vid_for_blog(youku.Youku.get_vid_from_url(url), **dict(info_only=False, json_output=True))
        cache[url] = json.dumps(re)
        response.set_header('Access-Control-Allow-Origin', '*')
        return cache[url]


@route('/qq')
def analysis_qq():
    url = request.query.url
    return json.dumps(patch_you_get_qq._download_by_url(url, output_dir='.', merge=True, info_only=False))

iqiyi.Iqiyi._download_by_url = patch_you_get_iqiyi._download_by_url


@route('/iqiyi')
def analysis_iqiyi():
    url = request.query.url
    #  print(url)
    iqy = iqiyi.Iqiyi()
    #  print(youku.Youku.get_vid_from_url(url))
    re = iqy._download_by_url(url, **dict(info_only=False, json_output=True))
    #  print(','.join(re))
    return ','.join(re)
    #  print(yk.__class__.__bases__[0]().streams)


@route('/cctv')
def analysis_cctv():
    # suppot 2 type
    # 首页 http://tv.cctv.com/2016/04/01/VIDE1Xph0qQ2SWGWgsqOJDJu160401.shtml
    # json http://vdn.apps.cntv.cn/api/getHttpVideoInfo.do?pid=6da606b52cfe48f89c0634475e695f20
    url = request.query.url
    if 'vdn.apps.cntv.cn' in url:
        cjson = requests.get(url).json()
        # get all owChapter
        urls = list(map(lambda x: x['url'], cjson['video']['lowChapters']))
        #  return ','.join(list(map(lambda x: re.sub(r'http://\d+\.\d+\.\d+\.\d+/v.cctv.com/', 'http://vod.cntv.lxdns.com/', x), urls)))
    else:
        if re.match(r'http://tv\.cctv\.com/video/(\w+)/(\w+)', url):
            id = common.match1(url, r'http://tv\.cctv\.com/video/\w+/(\w+)')
        elif re.match(r'http://\w+\.cctv\.com/(\w+/\w+/(classpage/video/)?)?\d+/\d+\.shtml', url) or re.match(r'http://\w+.cctv.com/(\d+/\d+/\d+/)VIDE\w+.shtml', url):
            # id = r1(r'videoCenterId","(\w+)"', get_html(url))
            id = common.r1(r'guid\ =\ "(\w+)"', common.get_html(url))
        elif re.match(r'http://sports.cntv.cn', url):
            id = common.r1(r'var _guid="(\w+)"', common.get_html(url))
        elif re.match(r'http://xiyou.cctv.com/v-[\w-]+\.html', url):
            id = common.r1(r'http://xiyou.cctv.com/v-([\w-]+)\.html', url)
        elif re.match(r'http://tv\.cntv\.cn/video/(\w+)/(\w+)', url):
            id = common.match1(url, r'http://tv\.cntv\.cn/video/\w+/(\w+)')
        elif re.match(r'http://\w+\.cntv\.cn/(\w+/\w+/(classpage/video/)?)?\d+/\d+\.shtml', url) or re.match(r'http://\w+.cntv.cn/(\w+/)*VIDE\d+.shtml', url):
            id = common.r1(r'videoCenterId","(\w+)"', get_html(url))
        elif re.match(r'http://xiyou.cntv.cn/v-[\w-]+\.html', url):
            id = common.r1(r'http://xiyou.cntv.cn/v-([\w-]+)\.html', url)
        else:
            raise NotImplementedError(url)
        print(id)
        urls = patch_you_get_cntv._download_by_id(id)
    return ','.join(patch_you_get_cntv._relace_ip_to_lxcdn(urls))


@route('/ifeng')
def analysis_ifeng():
    url = request.query.url
    #  print(request.query)
    id = common.r1(r'/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\.shtml$', url)
    # 01a255b5-7117-4e5a-af7c-0b37c58ff2d3
    #  print(id)
    if id:
        return patch_you_get_ifeng._download_by_id(id)

    html = common.get_html(url)
    id = common.r1(r'var vid="([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"', html)
    assert id, "can't find video info"
    return patch_you_get_ifeng._download_by_id(id)

@route('/bilibili')
def analysis_bilibili():
    url = request.query.url
    return json.dumps(patch_you_get_bilibili._download_by_url(url))

@route('/xiami')
def analysis_xiami():
    url = request.query.url
    return json.dumps(patch_you_get_xiami._download_by_url(url))

@route('/sohu')
def analysis_sohu():
    url = request.query.url
    return patch_you_get_sohu._download_by_url(url)

@route('/netease')
def analysis_netease():
    url = request.query.url
    return patch_you_get_netease._download_by_url(url)

@route('/letv')
def analysis_letv():
    url = request.query.url
    return json.dumps(patch_you_get_letv._video_info(url))

@route('/kugou')
def analysis_kugou():
    print(request.query.url)
    hash_val = request.query.hash
    album_id = request.query.album_id
    return patch_you_get_kugou._download_by_hash_and_album_id(hash_val, album_id)

#  @route('/letv')
#  def analysis_letv():
    #  url = request.query.url
    #  if re.match(r'http://yuntv.letv.com/', url):
        #  # TODO support
        #  #  letvcloud_download(url, output_dir=output_dir, merge=merge, info_only=info_only)
        #  pass
    #  else:
        #  common.get_content(url)
        #  if re.match(r'http://www.letv.com/ptv/vplay/(\d+).html', url):
            #  vid = match1(url, r'http://www.letv.com/ptv/vplay/(\d+).html')
        #  else:
            #  vid = match1(html, r'vid="(\d+)"')
    #  _download_by_id(id, output_dir=output_dir, merge=merge, info_only=info_only)


url = "http://v.youku.com/v_show/id_XMTQ0MzI4NDgyNA==.html"
#  url = "http://www.letv.com/ptv/vplay/24369067.html"
#  stream_id='flvhd'
#  common.any_download(url, **dict(stream_id='350', output_dir=None, merge=None, info_only=True, json_output=True, caption=True))
#  http://stackoverflow.com/questions/4502141/how-to-get-attributes-from-parent
#  common.download_main(common.any_download, common.any_download_playlist, url, False, stream_id=None, output_dir=None, merge=None, info_only=False, json_output=True, caption=True)

#  def yk__init__(self, *args):
    #  print("hello, youku")
    #  super(youku.Youku, self).__init__(args)
    #  self._streams = self.streams

#  def get_streams(self):
    #  print(self)
    #  return self.streams


#  youku.Youku.__init__ = yk__init__
#  youku.Youku.get_streams = get_streams
#  youku.Youku.extract = extract_2

#  youku.Youku.__slots__ = ['streams']
#  yk = youku.Youku()
#  print(yk)
#  print(yk.streams)
#  print(youku.Youku.get_vid_from_url(url))
#  re = yk._download_by_vid(youku.Youku.get_vid_from_url(url), **dict(info_only=False, json_output=True, stream_id='3gphd'))
#  yk.streams={'aaa':22}
#  import pdb; pdb.set_trace()
# extractor.py 最后的 self.__init__() 真是 what the fuck
#  re = yk.download_by_url(url, **dict(info_only=False, json_output=True))
#  print(re)
#  print(super(yk.__class__, yk).streams)
#  yk.download_by_url()
#  print(yk)
#  print("=========>", yk.streams)
#  print("=========>", yk.url)
#  print(yk.streams_parameter)
#  print(yk.__class__.__bases__[0]().streams)
#  print(yk.get_streams())
#  print(yk._streams)
#  print(dir(yk.__class__.__bases__[0]()))
#  sys.exit(1)


@route('/get_kugou_realurl')
def get_kugou_real_url():
    """return kugou real url"""
    real_url = None
    hash_val = request.query.hash_val
    if hash_val:
        real_url = kugou.get_kugou_download_url_by_hash(hash_val)
    return real_url


@route('/get_letvcloud_realurl')
def get_letvcloud_real_url():
    real_url = None
    vu = request.query.vu
    uu = request.query.uu
    title = "LETV-%s" % vu
    if vu and uu and title:
        real_url = letv.get_download_url_by_vu(vu, uu, title=title)
    return real_url


@route('/get_sohu_realurl')
def get_sohu_real_url():
    real_url = None
    url = request.query.url
    if url:
        real_url = sohu.get_sohu_download_url(url)
    return real_url


@route('/get_qq_realurl')
def get_qq_real_url():
    real_url = None
    url = request.query.url
    if url:
        real_url = qq.get_qq_download_url(url)
    return real_url

run(host='0.0.0.0', port=8188, reloader=False, server='gunicorn', workers=3)
