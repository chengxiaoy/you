#!/usr/bin/env python
# -*- coding: utf-8 -*-

from you_get.common import *
from you_get.extractors import VideoExtractor

import base64
import ssl
import time
import traceback


def _download_by_url(self, url, **kwargs):
        self.url = url

        set_proxy(("61.147.111.100",7777))
        self.prepare(**kwargs)

        try:
            self.streams_sorted = [dict([('id', stream_type['id'])] + list(self.streams[stream_type['id']].items())) for stream_type in self.__class__.stream_types if stream_type['id'] in self.streams]
        except:
            self.streams_sorted = [dict([('itag', stream_type['itag'])] + list(self.streams[stream_type['itag']].items())) for stream_type in self.__class__.stream_types if stream_type['itag'] in self.streams]

        kwargs['stream_id'] = self.streams_sorted[-1]['id']
        self.extract(**kwargs)
        return self.streams[kwargs['stream_id']]['src']

