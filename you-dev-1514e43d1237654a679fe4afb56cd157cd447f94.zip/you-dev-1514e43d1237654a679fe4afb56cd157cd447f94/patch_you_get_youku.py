#!/usr/bin/env python
# -*- coding: utf-8 -*-

from you_get.common import *
from you_get.extractors import VideoExtractor

import base64
import ssl
import time
import traceback

def _download_by_url(self, url, **kwargs):
    self.url = url
    self.vid = None

    if 'extractor_proxy' in kwargs and kwargs['extractor_proxy']:
        set_proxy(parse_host(kwargs['extractor_proxy']))
    self.prepare(**kwargs)
    if self.out:
        return
    if 'extractor_proxy' in kwargs and kwargs['extractor_proxy']:
        unset_proxy()

    try:
        self.streams_sorted = [dict([('id', stream_type['id'])] + list(self.streams[stream_type['id']].items())) for stream_type in self.__class__.stream_types if stream_type['id'] in self.streams]
    except:
        self.streams_sorted = [dict([('itag', stream_type['itag'])] + list(self.streams[stream_type['itag']].items())) for stream_type in self.__class__.stream_types if stream_type['itag'] in self.streams]

    self.extract(**kwargs)
    kwargs['stream_id'] = self.streams_sorted[-1]['id']
    return self.streams[kwargs['stream_id']]['src']

def _download_by_vid(self, vid, **kwargs):
        self.vid = vid

        if 'extractor_proxy' in kwargs and kwargs['extractor_proxy']:
            set_proxy(parse_host(kwargs['extractor_proxy']))
        self.prepare(**kwargs)
        if 'extractor_proxy' in kwargs and kwargs['extractor_proxy']:
            unset_proxy()

        try:
            self.streams_sorted = [dict([('id', stream_type['id'])] + list(self.streams[stream_type['id']].items())) for stream_type in self.__class__.stream_types if stream_type['id'] in self.streams]
        except:
            self.streams_sorted = [dict([('itag', stream_type['itag'])] + list(self.streams[stream_type['itag']].items())) for stream_type in self.__class__.stream_types if stream_type['itag'] in self.streams]
        #  print(self.streams_sorted)
        # 最低清
        #  print(self.streams_sorted[-1]['id'])
        kwargs['stream_id'] = self.streams_sorted[-1]['id']
        self.extract(**kwargs)
        return self.streams[kwargs['stream_id']]['src']

# only for tech-training-blog's youku passworded video
# @see git@gitlab.ximalaya.com:blog/tech-training-blog.git
def _download_by_vid_for_blog(self, vid, **kwargs):
        self.vid = vid
        self.password = 'Dev321987'

        if 'extractor_proxy' in kwargs and kwargs['extractor_proxy']:
            set_proxy(parse_host(kwargs['extractor_proxy']))
        self.prepare(**kwargs)
        if 'extractor_proxy' in kwargs and kwargs['extractor_proxy']:
            unset_proxy()

        try:
            self.streams_sorted = [dict([('id', stream_type['id'])] + list(self.streams[stream_type['id']].items())) for stream_type in self.__class__.stream_types if stream_type['id'] in self.streams]
        except:
            self.streams_sorted = [dict([('itag', stream_type['itag'])] + list(self.streams[stream_type['itag']].items())) for stream_type in self.__class__.stream_types if stream_type['itag'] in self.streams]
        #  print(self.streams_sorted)
        #  import json
        #  print(json.dumps(self.streams_sorted, indent=2))
        # 只有高清的是 mp4, 没有高清的返错
        kwargs['stream_id'] = self.streams_sorted[-2]['id']
        self.extract(**kwargs)
        #  print(self.streams)
        return self.streams[kwargs['stream_id']]['src']


# prepare with out input(may be block when meet video need password!)
# 注意，下面仅仅改动了 self.password
# 如果 you-get 更新 查看 prepare 是否改动过！
# 如果 you-get 更新 查看 prepare 是否改动过！
# 如果 you-get 更新 查看 prepare 是否改动过！
# 如果 you-get 更新 查看 prepare 是否改动过！
# 如果 you-get 更新 查看 prepare 是否改动过！
# 如果 you-get 更新 查看 prepare 是否改动过！
# 如果 you-get 更新 查看 prepare 是否改动过！

def prepare(self, **kwargs):
        # Hot-plug cookie handler
        ssl_context = request.HTTPSHandler(
            context=ssl.SSLContext(ssl.PROTOCOL_TLSv1))
        cookie_handler = request.HTTPCookieProcessor()
        if 'extractor_proxy' in kwargs and kwargs['extractor_proxy']:
            proxy = parse_host(kwargs['extractor_proxy'])
            proxy_handler = request.ProxyHandler({
                'http': '%s:%s' % proxy,
                'https': '%s:%s' % proxy,
            })
        else:
            proxy_handler = request.ProxyHandler({})
        opener = request.build_opener(ssl_context, cookie_handler, proxy_handler)
        opener.addheaders = [('Cookie','__ysuid={}'.format(time.time()))]
        request.install_opener(opener)

        assert self.url or self.vid

        if self.url and not self.vid:
            self.vid = self.__class__.get_vid_from_url(self.url)

            if self.vid is None:
                self.download_playlist_by_url(self.url, **kwargs)
                exit(0)

        #HACK!
        if 'api_url' in kwargs:
            api_url = kwargs['api_url']  #85
            api12_url = kwargs['api12_url']  #86
            self.ctype = kwargs['ctype']
            self.title = kwargs['title']

        else:
            api_url = 'http://play.youku.com/play/get.json?vid=%s&ct=10' % self.vid
            api12_url = 'http://play.youku.com/play/get.json?vid=%s&ct=12' % self.vid

        try:
            meta = json.loads(get_content(
                api_url,
                headers={'Referer': 'http://static.youku.com/'}
            ))
            meta12 = json.loads(get_content(
                api12_url,
                headers={'Referer': 'http://static.youku.com/'}
            ))
            data = meta['data']
            data12 = meta12['data']
            assert 'stream' in data
        except AssertionError:
            if 'error' in data:
                if data['error']['code'] == -202:
                    # Password protected
                    self.password_protected = True
                    #  self.password = input(log.sprint('Password: ', log.YELLOW))
                    if not self.password:
                        self.password = ''
                    api_url += '&pwd={}'.format(self.password)
                    api12_url += '&pwd={}'.format(self.password)
                    meta = json.loads(get_content(
                        api_url,
                        headers={'Referer': 'http://static.youku.com/'}
                    ))
                    meta12 = json.loads(get_content(
                        api12_url,
                        headers={'Referer': 'http://static.youku.com/'}
                    ))
                    data = meta['data']
                    data12 = meta12['data']
                else:
                    log.wtf('[Failed] ' + data['error']['note'])
            else:
                log.wtf('[Failed] Video not found.')

        if not self.title:  #86
            self.title = data['video']['title']
        self.ep = data12['security']['encrypt_string']
        self.ip = data12['security']['ip']

        if 'stream' not in data and self.password_protected:
            log.wtf('[Failed] Wrong password.')

        stream_types = dict([(i['id'], i) for i in self.stream_types])
        audio_lang = data['stream'][0]['audio_lang']

        for stream in data['stream']:
            stream_id = stream['stream_type']
            if stream_id in stream_types and stream['audio_lang'] == audio_lang:
                if 'alias-of' in stream_types[stream_id]:
                    stream_id = stream_types[stream_id]['alias-of']

                if stream_id not in self.streams:
                    self.streams[stream_id] = {
                        'container': stream_types[stream_id]['container'],
                        'video_profile': stream_types[stream_id]['video_profile'],
                        'size': stream['size'],
                        'pieces': [{
                            'fileid': stream['stream_fileid'],
                            'segs': stream['segs']
                        }]
                    }
                else:
                    self.streams[stream_id]['size'] += stream['size']
                    self.streams[stream_id]['pieces'].append({
                        'fileid': stream['stream_fileid'],
                        'segs': stream['segs']
                    })

        self.streams_fallback = {}
        for stream in data12['stream']:
            stream_id = stream['stream_type']
            if stream_id in stream_types and stream['audio_lang'] == audio_lang:
                if 'alias-of' in stream_types[stream_id]:
                    stream_id = stream_types[stream_id]['alias-of']

                if stream_id not in self.streams_fallback:
                    self.streams_fallback[stream_id] = {
                        'container': stream_types[stream_id]['container'],
                        'video_profile': stream_types[stream_id]['video_profile'],
                        'size': stream['size'],
                        'pieces': [{
                            'fileid': stream['stream_fileid'],
                            'segs': stream['segs']
                        }]
                    }
                else:
                    self.streams_fallback[stream_id]['size'] += stream['size']
                    self.streams_fallback[stream_id]['pieces'].append({
                        'fileid': stream['stream_fileid'],
                        'segs': stream['segs']
                    })

        # Audio languages
        if 'dvd' in data and 'audiolang' in data['dvd']:
            self.audiolang = data['dvd']['audiolang']
            for i in self.audiolang:
                i['url'] = 'http://v.youku.com/v_show/id_{}'.format(i['vid'])

