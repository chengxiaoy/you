#!/usr/bin/env python
# -*- coding: utf-8 -*-

from you_get.common import *

import json
import re


def _download_by_id(id, title=None, output_dir='.', merge=True, info_only=False):
    assert id
    info = json.loads(get_html('http://vdn.apps.cntv.cn/api/getHttpVideoInfo.do?pid=' + id))
    title = title or info['title']
    video = info['video']
    # alternatives = [x for x in video.keys() if x.endswith('hapters')]
    # assert alternatives in (['chapters'], ['lowChapters', 'chapters'], ['chapters', 'lowChapters']), alternatives
    chapters = video['chapters'] if 'chapters' in video else video['lowChapters']
    urls = [x['url'] for x in chapters]
    ext = r1(r'\.([^.]+)$', urls[0])
    assert ext in ('flv', 'mp4')
    return urls


def _relace_ip_to_lxcdn(urls):
    '''
    in [http://192/xx.mp4, http://193/xx.mp4]
    out [http://lxcdn/xx.mp4, http://lxcdn/xx.mp4]
    '''
    return list(map(lambda x: re.sub(r'http://\d+\.\d+\.\d+\.\d+/v.cctv.com/',
                'http://vod.cntv.lxdns.com/', x), urls))
