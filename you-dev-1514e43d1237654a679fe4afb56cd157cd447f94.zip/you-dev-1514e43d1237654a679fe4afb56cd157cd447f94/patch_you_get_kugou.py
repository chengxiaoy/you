#!/usr/bin/env python
# -*- coding: utf-8 -*-

from you_get.common import *

import re
from json import loads
from base64 import b64decode
import re
import hashlib


def _download_by_hash_and_album_id(hash_val, album_id):
    #sample
    #url_sample:http://www.kugou.com/yy/album/single/536957.html
    #hash ->key  md5(hash+kgcloud")->key  decompile swf
    #cmd 4 for mp3 cmd 3 for m4a
    #key=hashlib.new('md5',(hash_val+"kgcloudv2").encode("utf-8")).hexdigest()
    html=get_html("http://www.kugou.com/yy/index.php?r=play/getdata&hash={}&album_id={}&_={}".format(hash_val, album_id, int(time.time() * 1000)))
    #html=get_html("http://trackercdn.kugou.com/i/v2/?key=%s&module=&hash=%s&cdnBackup=1&pid=6&behavior=play&cmd=23&appid=2739"%(key,hash_val))
    j=loads(html)
    url=j['data']['play_url']
    return url

