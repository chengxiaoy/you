
# you

you = you-get + youtube-dl


use both you-get and youtube-dl as submodule, for analysis real video site url

use monkey patch to origin code, easy to upgrade deps


### deps:

https://github.com/soimort/you-get.git
https://github.com/rg3/youtube-dl.git



### tips

debug with pdb

import pdb; pdb.set_trace()


pp supervsior

```
/usr/bin/python /usr/bin/supervisord -c /srv/supervisor/supervisord.conf
```
