#!/usr/bin/env python
# -*- coding: utf-8 -*-

from you_get.common import *
from you_get.extractors import VideoExtractor

from you_get.extractors.sina import video_info, video_info_xml
from you_get.extractors.tudou import tudou_download_by_id
from you_get.extractors.youku import youku_download_by_vid
#from you_get.extractors.bilibili import get_srt_xml, parse_cid_playurl

import hashlib
import re

appkey = 'f3bb208b3d081dc8'
SECRETKEY_MINILOADER = '1c15888dc316e05a15fdd0a02ed6584f'

import base64
import ssl
import time
import traceback


#def _download_by_url(url):
#    if re.match(r'https?://bangumi\.bilibili\.com/', url):
#        # quick hack for bangumi URLs
#        html = get_content(url)
#        url = r1(r'"([^"]+)" class="v-av-link"', html)
#
#    html = get_content(url)
#    aid = r1(r'av(\d+)', url)
#    page = 1
#    api = 'http://www.bilibili.com/m/html5?aid=%s&page=%s' % (aid, page)
#    info = json.loads(get_content(api))
#    src = info['src']
#    return [src]

def _download_by_url(url):
    urls = []
    html = get_content(url)

    if re.match(r'https?://bangumi\.bilibili\.com/', url):
        # quick hack for bangumi URLs
        url = r1(r'"([^"]+)" class="v-av-link"', html)
        html = get_content(url)

    title = r1_of([r'<meta name="title" content="\s*([^<>]{1,999})\s*" />',
                   r'<h1[^>]*>\s*([^<>]+)\s*</h1>'], html)
    if title:
        title = unescape_html(title)
        title = escape_file_path(title)

    flashvars = r1_of([r'(cid=\d+)', r'(cid: \d+)', r'flashvars="([^"]+)"',
                       r'"https://[a-z]+\.bilibili\.com/secure,(cid=\d+)(?:&aid=\d+)?"'], html)
    assert flashvars
    flashvars = flashvars.replace(': ', '=')
    t, cid = flashvars.split('=', 1)
    cid = cid.split('&')[0]
    if t == 'cid':
        # multi-P
        cids = []
        pages = re.findall('<option value=\'([^\']*)\'', html)
        titles = re.findall('<option value=.*>\s*([^<>]+)\s*</option>', html)
        for i, page in enumerate(pages):
            html = get_html("http://www.bilibili.com%s" % page)
            flashvars = r1_of([r'(cid=\d+)',
                               r'flashvars="([^"]+)"',
                               r'"https://[a-z]+\.bilibili\.com/secure,(cid=\d+)(?:&aid=\d+)?"'], html)
            if flashvars:
                t, cid = flashvars.split('=', 1)
                cids.append(cid.split('&')[0])
            if url.endswith(page):
                cids = [cid.split('&')[0]]
                titles = [titles[i]]
                break

        # no multi-P
        if not pages:
            cids = [cid]
            titles = [r1(r'<option value=.* selected>\s*([^<>]+)\s*</option>', html) or title]

        for i in range(len(cids)):
            urls += bilibili_download_by_cid(cids[i],
                                     titles[i])

    elif t == 'vid':
        urls = sina_download_by_vid(cid, title=title)
    elif t == 'ykid':
        urls = youku_download_by_vid(cid, title=title)
    elif t == 'uid':
        urls = tudou_download_by_id(cid, title)
    else:
        raise NotImplementedError(flashvars)

    return urls


def bilibili_download_by_cid(cid, title):
    sign_this = hashlib.md5(bytes('cid={cid}&from=miniplay&player=1{SECRETKEY_MINILOADER}'.format(cid = cid, SECRETKEY_MINILOADER = SECRETKEY_MINILOADER), 'utf-8')).hexdigest()
    url = 'http://interface.bilibili.com/playurl?&cid=' + cid + '&from=miniplay&player=1' + '&sign=' + sign_this
    urls = [i
            if not re.match(r'.*\.qqvideo\.tc\.qq\.com', i)
            else re.sub(r'.*\.qqvideo\.tc\.qq\.com', 'http://vsrc.store.qq.com', i)
            for i in parse_cid_playurl(get_content(url))]

    type_ = ''
    size = 0
    try:
        for url in urls:
            _, type_, temp = url_info(url)
            size += temp or 0
    except error.URLError:
        log.wtf('[Failed] DNS not resolved. Please change your DNS server settings.')

    return urls

def sina_download_by_vid(vid, title=None):
    """Downloads a Sina video by its unique vid.
    http://video.sina.com.cn/
    """

    xml = video_info_xml(vid)
    urls, name, vstr = video_info(xml)
    return urls
