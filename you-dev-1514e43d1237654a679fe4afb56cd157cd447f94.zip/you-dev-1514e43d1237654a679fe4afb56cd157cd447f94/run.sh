#!/bin/bash

trap "kill -- -$$" EXIT

cd /srv/you
/home/caorong/.pyenv/versions/3.5.1/bin/python you.py

