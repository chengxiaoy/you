#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import json
from you_get.common import *
from you_get.extractors.xiami import parseString, location_dec

def _download_by_url(url):
    html = get_html(url, faker=True)
    sid = r1(r'rel="canonical" href="http://www.xiami.com/song/([^"]+)"', html)
    xml = get_html('http://www.xiami.com/song/playlist/id/%s/object_name/default/object_id/0' % sid, faker = True)
    doc = parseString(xml)
    i = doc.getElementsByTagName("track")[0]
    url = location_dec(i.getElementsByTagName("location")[0].firstChild.nodeValue)
    return [url]
